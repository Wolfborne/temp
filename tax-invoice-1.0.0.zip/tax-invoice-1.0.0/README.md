# Tax Invoice Skill - 电子税务局发票自动化

## 简介

这是一个 OpenClaw Skill，用于自动化操作国家税务总局电子税务局，支持：

- ✅ 蓝字发票开具
- ✅ 发票草稿保存/批量保存
- ✅ 税收分类编码取证
- ✅ 发票模板收集

## 安装

1. 解压此压缩包
2. 将文件夹复制到 OpenClaw skills 目录：
   ```bash
   cp -r tax-invoice-1.0.0 ~/.openclaw/workspace/skills/tax-invoice
   ```

## 前置要求

- OpenClaw 已安装并配置
- Chrome 浏览器
- Browser Relay 已连接（用于连接用户自己的 Chrome）
- **Windows 用户**: PowerShell 5.1 或更高版本

## 快速开始

### 1. 配置企业信息（可选）

**Linux/Mac:**
```bash
cd ~/.openclaw/workspace/skills/tax-invoice/config
cp company.json.example company.json
# 编辑 company.json 填入企业信息
```

**Windows:**
```powershell
cd ~\.openclaw\workspace\skills\tax-invoice\config
Copy-Item company.json.example company.json
# 编辑 company.json 填入企业信息
```

### 2. 验证浏览器连接

```bash
# Linux/Mac
openclaw browser --browser-profile chrome status
openclaw browser --browser-profile chrome tabs

# Windows (PowerShell)
openclaw browser --browser-profile chrome status
openclaw browser --browser-profile chrome tabs
```

### 3. 开始使用

在 OpenClaw 对话中提及：
- "帮我开一张发票"
- "保存发票草稿"
- "查询税收分类编码"

## 文件结构

```
tax-invoice/
├── SKILL.md              # 主技能文档
├── README.md             # 本文件
├── scripts/              # 执行脚本
│   ├── run-blue-invoice.sh      # 蓝字发票开票脚本
│   ├── blue-invoice-run.template.js
│   └── inject-draft-save.js     # 草稿注入脚本
├── pages/                # 页面文档
│   ├── blue-invoice/     # 蓝字发票页面
│   ├── login/            # 登录页面
│   ├── draft-list/       # 草稿列表
│   └── red-invoice/      # 红字发票
├── references/           # 参考文档
│   ├── collection-and-customer-flow.md
│   ├── page-state-decision.md
│   ├── blue-invoice-entry-sop.md
│   └── blue-invoice-fill-sop.md
├── assets/               # 模板文件
│   └── tax-invoice-template.xlsx
└── config/               # 配置目录
    └── company.json.example
```

## 使用说明

### 蓝字发票开具流程

1. **设备分流**：询问用户使用手机还是电脑
2. **信息收集**：收集购买方、项目、金额等信息
3. **用户确认**：展示信息供用户确认
4. **执行开票**：发送等待话术后立即执行
5. **预览确认**：发送预览图等待用户最终确认

### 跨平台脚本使用

> **重要说明**：以下示例仅展示脚本调用方式。实际发票信息（购买方、金额等）由 OpenClaw 根据你与客户的**实时对话动态生成**，自动传入脚本执行。

**Linux/Mac:**
```bash
cd ~/.openclaw/workspace/skills/tax-invoice
INVOICE_TYPE='增值税专用发票' \
BUYER_NAME='公司名' \
PROJECT_NAME='*现代服务*服务费' \
AMOUNT_VALUE='5000' \
REMARK_VALUE='备注' \
./scripts/run-blue-invoice.sh
```

**Windows (PowerShell):**
```powershell
cd ~\.openclaw\workspace\skills\tax-invoice
$env:INVOICE_TYPE = '增值税专用发票'
$env:BUYER_NAME = '公司名'
$env:PROJECT_NAME = '*现代服务*服务费'
$env:AMOUNT_VALUE = '5000'
$env:REMARK_VALUE = '备注'
.\scripts\run-blue-invoice.ps1
```

### 关键规则

- 正式客户第一句必须先问"手机还是电脑"
- 用户确认后必须发送固定等待话术
- 话术后必须立即执行浏览器操作（不能只说不动）
- 只能发一张最终预览图给客户
- "发票开具"按钮绝对不能自动点击

## 注意事项

⚠️ **重要**：此 skill 需要连接用户自己的 Chrome 浏览器，通过 Browser Relay 进行操作。确保：

1. Chrome 已安装
2. Browser Relay 插件已安装并启用
3. 已登录电子税务局

## 故障排查

### 浏览器连接失败
```bash
# 检查 browser 状态
openclaw browser --browser-profile chrome status

# 重启 browser
openclaw browser stop
openclaw browser start
```

### 页面元素找不到
- 检查是否有多余的浏览器插件遮挡
- 尝试清理浏览器缓存
- 确认页面已完全加载

## 版本历史

### v1.0.0
- 初始版本
- 支持蓝字发票开具
- 支持草稿保存
- 修复"只说不做"执行问题

## 许可证

MIT License

## 作者

OpenClaw Community
