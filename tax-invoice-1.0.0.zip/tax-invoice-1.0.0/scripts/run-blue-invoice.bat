@echo off
REM Windows 版蓝字发票开票脚本
REM 用法: run-blue-invoice.bat

setlocal EnableDelayedExpansion

set "PROFILE=%BROWSER_PROFILE%"
if "!PROFILE!"=="" set "PROFILE=chrome"

set "SCRIPT_DIR=%~dp0"
set "TEMPLATE=%SCRIPT_DIR%blue-invoice-run.template.js"

REM 检查必需的环境变量
if "!INVOICE_TYPE!"=="" (
    echo 错误: INVOICE_TYPE 环境变量未设置
    exit /b 1
)
if "!BUYER_NAME!"=="" (
    echo 错误: BUYER_NAME 环境变量未设置
    exit /b 1
)
if "!PROJECT_NAME!"=="" (
    echo 错误: PROJECT_NAME 环境变量未设置
    exit /b 1
)
if "!AMOUNT_VALUE!"=="" (
    echo 错误: AMOUNT_VALUE 环境变量未设置
    exit /b 1
)
if "!REMARK_VALUE!"=="" (
    echo 错误: REMARK_VALUE 环境变量未设置
    exit /b 1
)

REM 创建临时文件
set "FN_FILE=%TEMP%\blue-invoice-fn-%RANDOM%.js"

REM 使用 Python 处理模板
python3 - "%TEMPLATE%" "%FN_FILE%" <<'PY'
import json, sys
from pathlib import Path

template_path = Path(sys.argv[1])
out_path = Path(sys.argv[2])
text = template_path.read_text(encoding='utf-8')
repls = {
    '__INVOICE_TYPE__': json.dumps(__import__('os').environ['INVOICE_TYPE'], ensure_ascii=False),
    '__BUYER_NAME__': json.dumps(__import__('os').environ['BUYER_NAME'], ensure_ascii=False),
    '__PROJECT_NAME__': json.dumps(__import__('os').environ['PROJECT_NAME'], ensure_ascii=False),
    '__AMOUNT_VALUE__': json.dumps(__import__('os').environ['AMOUNT_VALUE'], ensure_ascii=False),
    '__REMARK_VALUE__': json.dumps(__import__('os').environ['REMARK_VALUE'], ensure_ascii=False),
}
for old, new in repls.items():
    text = text.replace(old, new)
out_path.write_text(text, encoding='utf-8')
PY

if errorlevel 1 (
    echo 错误: Python 模板处理失败
    exit /b 1
)

REM 读取生成的 JS 文件并执行
set /p JS_CONTENT=<"%FN_FILE%"

REM 执行浏览器脚本
for /f "delims=" %%a in ('openclaw browser --browser-profile %PROFILE% evaluate --fn "%JS_CONTENT%"') do (
    set "RESULT=%%a"
    echo %%a
)

REM 清理临时文件
del "%FN_FILE%" 2>nul

REM 检查是否成功并截图
echo %RESULT% | findstr "\"ok\": true" >nul
if %errorlevel% == 0 (
    echo %RESULT% | findstr "\"step\": \"click-preview\"" >nul
    if %errorlevel% == 0 (
        timeout /t 1 /nobreak >nul
        openclaw browser --browser-profile %PROFILE% screenshot
    )
)

endlocal
