#!/bin/sh
set -eu

PROFILE="${BROWSER_PROFILE:-chrome}"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
TEMPLATE="$SCRIPT_DIR/blue-invoice-run.template.js"

: "${INVOICE_TYPE:?INVOICE_TYPE is required}"
: "${BUYER_NAME:?BUYER_NAME is required}"
: "${PROJECT_NAME:?PROJECT_NAME is required}"
: "${AMOUNT_VALUE:?AMOUNT_VALUE is required}"
: "${REMARK_VALUE:?REMARK_VALUE is required}"

FN_FILE="$(mktemp /tmp/blue-invoice-fn.XXXXXX.js)"
cleanup() {
  rm -f "$FN_FILE"
}
trap cleanup EXIT INT TERM

python3 - "$TEMPLATE" "$FN_FILE" <<'PY'
import json, sys
from pathlib import Path

template_path = Path(sys.argv[1])
out_path = Path(sys.argv[2])
text = template_path.read_text(encoding='utf-8')
repls = {
    '__INVOICE_TYPE__': json.dumps(__import__('os').environ['INVOICE_TYPE'], ensure_ascii=False),
    '__BUYER_NAME__': json.dumps(__import__('os').environ['BUYER_NAME'], ensure_ascii=False),
    '__PROJECT_NAME__': json.dumps(__import__('os').environ['PROJECT_NAME'], ensure_ascii=False),
    '__AMOUNT_VALUE__': json.dumps(__import__('os').environ['AMOUNT_VALUE'], ensure_ascii=False),
    '__REMARK_VALUE__': json.dumps(__import__('os').environ['REMARK_VALUE'], ensure_ascii=False),
}
for old, new in repls.items():
    text = text.replace(old, new)
out_path.write_text(text, encoding='utf-8')
PY

RESULT=$(openclaw browser --browser-profile "$PROFILE" evaluate --fn "$(cat "$FN_FILE")")
echo "$RESULT"

# 如果脚本成功执行到预览步骤，自动截图
if echo "$RESULT" | grep -q '"ok": true' && echo "$RESULT" | grep -q '"step": "click-preview"'; then
  sleep 1
  openclaw browser --browser-profile "$PROFILE" screenshot
fi
