() => {
  const invoiceType = __INVOICE_TYPE__;
  const buyerName = __BUYER_NAME__;
  const projectName = __PROJECT_NAME__;
  const amountValue = __AMOUNT_VALUE__;
  const remarkValue = __REMARK_VALUE__;

  const isVisible = (el) => {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style && style.visibility !== 'hidden' && style.display !== 'none' && rect.width > 0 && rect.height > 0;
  };

  const normalize = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  const setNativeValue = (el, value) => {
    const proto = Object.getPrototypeOf(el);
    const desc = Object.getOwnPropertyDescriptor(proto, 'value') || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
    if (desc && desc.set) desc.set.call(el, value);
    else el.value = value;
    el.dispatchEvent(new InputEvent('input', { bubbles: true, data: value.slice(-1) || '', inputType: 'insertText' }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  };

  const realClick = (el) => {
    if (!el) return false;
    el.scrollIntoView({ block: 'center', inline: 'center' });
    ['mousedown', 'mouseup', 'click'].forEach((type) => el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window })));
    if (typeof el.click === 'function') el.click();
    return true;
  };

  const clickImmediateEntry = () => {
    const candidates = [...document.querySelectorAll('*')].filter((el) => normalize(el.innerText) === '立即开票' && isVisible(el));
    const target =
      candidates.find((el) => el.classList.contains('invoice-entrance-choose')) ||
      candidates.find((el) => normalize(el.className).includes('invoice-entrance-choose')) ||
      candidates[0];

    if (!target) return { ok: false, step: 'click-immediate-entry', reason: 'ENTRY_NOT_FOUND', message: '未找到可见的“立即开票”节点' };
    realClick(target);
    return { ok: true, step: 'click-immediate-entry', text: normalize(target.innerText), tag: target.tagName, className: target.className || '' };
  };

  const findInvoiceTypeRoot = () => [...document.querySelectorAll('*')].find((el) => isVisible(el) && normalize(el.textContent).includes('选择票类') && !!el.querySelector('input[placeholder="请选择"]'));

  const selectInvoiceType = async () => {
    let root = findInvoiceTypeRoot();
    if (!root) {
      await sleep(500);
      root = findInvoiceTypeRoot();
    }
    if (!root) return { ok: false, step: 'select-invoice-type', reason: 'TYPE_ROOT_NOT_FOUND', message: '未找到“选择票类”区域' };

    const input = root.querySelector('input[placeholder="请选择"]') || root.querySelector('input');
    if (!input) return { ok: false, step: 'select-invoice-type', reason: 'TYPE_INPUT_NOT_FOUND', message: '未找到票类输入框' };

    realClick(input);

    let matchedItem = null;
    const deadline = Date.now() + 3000;
    while (Date.now() < deadline) {
      matchedItem = [...document.querySelectorAll('li,div')].find((el) => isVisible(el) && normalize(el.textContent) === invoiceType);
      if (matchedItem) break;
      await sleep(100);
    }
    if (!matchedItem) return { ok: false, step: 'select-invoice-type', reason: 'TYPE_ITEM_NOT_FOUND', target: invoiceType, message: '下拉已展开，但未找到匹配票类选项' };

    realClick(matchedItem);
    return { ok: true, step: 'select-invoice-type', selected: invoiceType, inputValue: input.value || normalize(input.textContent || '') };
  };

  const clickConfirm = async () => {
    let button = [...document.querySelectorAll('button,div')].find((el) => isVisible(el) && normalize(el.textContent) === '确定');
    if (!button) {
      await sleep(300);
      button = [...document.querySelectorAll('button,div')].find((el) => isVisible(el) && normalize(el.textContent) === '确定');
    }
    if (!button) return { ok: false, step: 'click-confirm', reason: 'CONFIRM_NOT_FOUND', message: '未找到可见的“确定”按钮' };

    realClick(button);
    await sleep(1500);
    return { ok: true, step: 'click-confirm', text: normalize(button.textContent) };
  };

  const dispatchInput = (el, value) => {
    el.focus();
    setNativeValue(el, value);
  };

  const findBuyerNameInput = () => document.querySelector('input[placeholder="请输入"]') || null;

  const getBuyerTaxIdValue = () => {
    const inputs = [...document.querySelectorAll('input.t-input__inner,input[placeholder="请输入"]')].filter(isVisible);
    return inputs[1]?.value || '';
  };

  const buyerOptionItems = () => [...document.querySelectorAll('.auto-complete__item')].filter((el) => isVisible(el));
  const buyerOptionCandidates = () => buyerOptionItems().map((el) => normalize(el.textContent)).filter(Boolean);
  const findExactBuyerOption = () => {
    const items = buyerOptionItems();
    const exact = items.find((el) => normalize(el.textContent) === buyerName);
    if (exact) return exact;
    // 若输入正确，第一项通常是目标，验证文本包含关系后作为兜底
    if (items.length > 0 && normalize(items[0].textContent).includes(buyerName)) return items[0];
    return null;
  };
  const candidateListVisible = () => !!buyerOptionItems().length;

  const trySelectBuyerOption = async (input, mode) => {
    const option = findExactBuyerOption();
    if (!option) {
      return {
        ok: false,
        step: 'select-buyer-name',
        mode,
        reason: 'EXACT_OPTION_NOT_FOUND',
        selected: '',
        clickedClass: '',
        finalValue: input.value || '',
        taxId: getBuyerTaxIdValue(),
        optionsSeen: buyerOptionCandidates()
      };
    }

    const beforeTaxId = getBuyerTaxIdValue();
    const beforeListVisible = candidateListVisible();
    realClick(option);
    await sleep(1200);
    const afterTaxId = getBuyerTaxIdValue();
    const afterListVisible = candidateListVisible();
    const taxIdChanged = !!afterTaxId && afterTaxId !== beforeTaxId;
    const listDismissed = beforeListVisible && !afterListVisible;
    const ok = taxIdChanged || listDismissed;

    return {
      ok,
      step: 'select-buyer-name',
      mode,
      reason: ok ? '' : 'CONTAINER_CLICK_NOT_CONFIRMED',
      selected: normalize(option.textContent),
      clickedClass: option.className || '',
      finalValue: input.value || '',
      beforeTaxId,
      taxId: afterTaxId,
      beforeListVisible,
      afterListVisible,
      taxIdChanged,
      listDismissed,
      optionsSeen: buyerOptionCandidates()
    };
  };

  const selectBuyerName = async () => {
    const input = findBuyerNameInput();
    if (!input) return { ok: false, step: 'select-buyer-name', reason: 'BUYER_INPUT_NOT_FOUND', message: '未找到购买方名称输入框' };

    realClick(input);
    setNativeValue(input, '');
    await sleep(120);

    setNativeValue(input, buyerName);
    await sleep(1000);
    let result = await trySelectBuyerOption(input, 'full-input-then-container-click');
    if (result?.ok) return result;

    setNativeValue(input, buyerName.slice(0, -1));
    await sleep(250);
    setNativeValue(input, buyerName);
    await sleep(650);
    result = await trySelectBuyerOption(input, 'disturb-then-container-click');
    if (result?.ok) return result;

    return {
      ok: false,
      step: 'select-buyer-name',
      reason: 'BUYER_OPTION_OR_TAXID_FAILED',
      target: buyerName,
      currentValue: input.value || '',
      taxId: getBuyerTaxIdValue(),
      optionsSeen: buyerOptionCandidates(),
      message: '购买方候选容器未稳定命中，或点击后候选状态/税号变化未被确认'
    };
  };

  const findProjectInput = () => {
    const rows = [...document.querySelectorAll('tr')].filter((tr) => isVisible(tr));
    for (const tr of rows) {
      const txt = normalize(tr.textContent);
      if (!txt.startsWith('1')) continue;
      const cells = [...tr.querySelectorAll('td')];
      for (const cell of cells) {
        const input = cell.querySelector('input[placeholder="请输入"]');
        const btn = cell.querySelector('button');
        if (input && btn && isVisible(input)) return input;
      }
    }
    return null;
  };

  const getProjectOptions = () => [...document.querySelectorAll('li,div')].filter((el) => isVisible(el) && normalize(el.textContent));

  const pickProjectOption = () => {
    const options = getProjectOptions();
    const exact = options.find((el) => normalize(el.textContent) === projectName);
    if (exact) return { mode: 'exact', el: exact };
    const closest = options.find((el) => {
      const text = normalize(el.textContent);
      return text.includes('现代服务') && (text.includes('推广') || text.includes('服务费'));
    });
    if (closest) return { mode: 'closest', el: closest };
    const broad = options.find((el) => normalize(el.textContent).includes('现代服务'));
    if (broad) return { mode: 'broad-closest', el: broad };
    return null;
  };

  const selectProjectName = async () => {
    const input = findProjectInput();
    if (!input) return { ok: false, step: 'select-project-name', reason: 'PROJECT_INPUT_NOT_FOUND', message: '未找到项目名称输入框' };

    realClick(input);
    setNativeValue(input, '');
    await sleep(80);

    for (let i = 1; i <= projectName.length; i++) {
      dispatchInput(input, projectName.slice(0, i));
      await sleep(120);
      const picked = pickProjectOption();
      if (picked) {
        realClick(picked.el);
        await sleep(500);
        return { ok: true, step: 'select-project-name', mode: picked.mode, selected: normalize(picked.el.textContent), finalValue: input.value || '' };
      }
    }

    const picked = pickProjectOption();
    if (picked) {
      realClick(picked.el);
      await sleep(500);
      return { ok: true, step: 'select-project-name', mode: picked.mode, selected: normalize(picked.el.textContent), finalValue: input.value || '' };
    }

    return { ok: false, step: 'select-project-name', reason: 'PROJECT_OPTION_NOT_FOUND', target: projectName, message: '未找到匹配项目项，也没有合适的近似项' };
  };

  const findAmountInput = () => {
    const rows = [...document.querySelectorAll('tr')].filter((tr) => isVisible(tr));
    for (const tr of rows) {
      const txt = normalize(tr.textContent);
      if (!txt.startsWith('1')) continue;
      const inputs = [...tr.querySelectorAll('input[placeholder="请输入"]')].filter(isVisible);
      if (inputs.length >= 6) return inputs[5];
    }
    return null;
  };

  const findSafeBlurTarget = () => {
    const preferred = [...document.querySelectorAll('td,div,span')].find((el) => {
      if (!isVisible(el)) return false;
      if (el.querySelector('input,button,textarea,select')) return false;
      const text = normalize(el.textContent);
      return text === '合计' || text.includes('价税合计（小写）') || text.includes('价税合计（大写）');
    });
    if (preferred) return preferred;
    return document.body;
  };

  const fillAmount = async () => {
    const input = findAmountInput();
    if (!input) return { ok: false, step: 'fill-amount', reason: 'AMOUNT_INPUT_NOT_FOUND', message: '未找到金额列输入框' };

    realClick(input);
    await sleep(120);
    setNativeValue(input, '');
    await sleep(80);
    for (let i = 1; i <= amountValue.length; i++) {
      setNativeValue(input, amountValue.slice(0, i));
      await sleep(120);
    }
    const beforeBlur = input.value || '';
    realClick(findSafeBlurTarget());
    input.blur();
    await sleep(500);
    return { ok: true, step: 'fill-amount', beforeBlur, afterBlur: input.value || '' };
  };

  const findRemarkInput = () => document.querySelector('textarea') || [...document.querySelectorAll('input,textarea')].find((el) => isVisible(el) && (el.placeholder || '').includes('如开票人对备注文本长度等有特殊需求')) || null;

  const fillRemark = async () => {
    const input = findRemarkInput();
    if (!input) return { ok: false, step: 'fill-remark', reason: 'REMARK_INPUT_NOT_FOUND', message: '未找到备注输入框' };

    realClick(input);
    await sleep(120);
    setNativeValue(input, '');
    await sleep(80);
    for (let i = 1; i <= remarkValue.length; i++) {
      setNativeValue(input, remarkValue.slice(0, i));
      await sleep(120);
    }
    return { ok: true, step: 'fill-remark', finalValue: input.value || '' };
  };

  const clickPreview = async () => {
    let button = [...document.querySelectorAll('button,div')].find((el) => isVisible(el) && normalize(el.textContent) === '预览发票');
    if (!button) {
      await sleep(300);
      button = [...document.querySelectorAll('button,div')].find((el) => isVisible(el) && normalize(el.textContent) === '预览发票');
    }
    if (!button) return { ok: false, step: 'click-preview', reason: 'PREVIEW_BUTTON_NOT_FOUND', message: '未找到预览发票按钮' };

    realClick(button);
    await sleep(1000);
    const previewVisible = [...document.querySelectorAll('*')].some((el) => isVisible(el) && (normalize(el.textContent).includes('价税合计（大写）') || normalize(el.textContent) === '关闭' || normalize(el.textContent).includes('备注')));
    return { ok: previewVisible, step: 'click-preview', previewVisible };
  };

  return (async () => {
    const first = clickImmediateEntry();
    if (!first.ok) return first;
    await sleep(500);

    const second = await selectInvoiceType();
    if (!second.ok) return { ok: false, steps: [first, second] };

    const third = await clickConfirm();
    if (!third.ok) return { ok: false, steps: [first, second, third] };

    const fourth = await selectBuyerName();
    if (!fourth.ok) return { ok: false, steps: [first, second, third, fourth] };

    const fifth = await selectProjectName();
    if (!fifth.ok) return { ok: false, steps: [first, second, third, fourth, fifth] };

    const sixth = await fillAmount();
    if (!sixth.ok) return { ok: false, steps: [first, second, third, fourth, fifth, sixth] };

    const seventh = await fillRemark();
    if (!seventh.ok) return { ok: false, steps: [first, second, third, fourth, fifth, sixth, seventh] };

    const eighth = await clickPreview();
    return { ok: eighth.ok, steps: [first, second, third, fourth, fifth, sixth, seventh, eighth] };
  })()
}