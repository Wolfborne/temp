/**
 * 税务发票 - 批量保存草稿注入脚本
 * 
 * 使用方式：通过 browser evaluate 注入到发票开具页面
 * 页面：https://dppt.beijing.chinatax.gov.cn:8443/blue-invoice-makeout/invoice-makeout
 * 
 * 原理：hook JSON.stringify，在数据被 znhd-sdk 加密前修改字段内容，
 *       然后循环点击"保存草稿"按钮，每次生成新的 UUID 创建新草稿。
 */

function batchSaveDrafts(drafts) {
  // drafts: Array<{ gmfdz, gmfmc, gmfnsrsbh, gmflxdh, gmfkhh, gmfyhzh, bz, skr, fhr, gmfjbr, ... }>
  // 每个 draft 对象里的字段会覆盖到发票数据上
  
  const orig = window._origStringify || JSON.stringify;
  if (!window._origStringify) window._origStringify = orig;

  const results = [];
  let currentIndex = 0;

  return new Promise(resolve => {
    // 安装拦截器
    JSON.stringify = function (...args) {
      const obj = args[0];
      if (obj && typeof obj === 'object' && obj.fhr !== undefined
          && obj.skr !== undefined && currentIndex < drafts.length) {
        const draft = drafts[currentIndex];
        const uuid = crypto.randomUUID();
        obj.kjlp = uuid;

        // 覆盖 draft 中指定的所有字段
        for (const [key, value] of Object.entries(draft)) {
          obj[key] = value;
        }

        results.push({ index: currentIndex + 1, uuid, ...draft });
        currentIndex++;
      }
      return orig.apply(this, args);
    };

    function clickSave() {
      const btn = [...document.querySelectorAll('button')]
        .find(b => b.textContent.trim() === '保存草稿');
      if (btn) btn.click();
    }

    function closeDialog() {
      return new Promise(r => {
        const check = setInterval(() => {
          const btn = [...document.querySelectorAll('button')]
            .find(b => b.textContent.trim() === '我知道了');
          if (btn) {
            clearInterval(check);
            btn.click();
            setTimeout(() => r(), 300);
          }
        }, 200);
        setTimeout(() => { clearInterval(check); r(); }, 5000);
      });
    }

    async function run() {
      for (let i = 0; i < drafts.length; i++) {
        clickSave();
        await closeDialog();
      }
      // 还原 JSON.stringify
      JSON.stringify = orig;
      resolve(orig(results));
    }

    run();
  });
}

/**
 * 常用字段名对照表（拼音缩写 → 中文含义）：
 * 
 * kjlp        - 草稿UUID（自动生成）
 * gmfmc       - 购买方名称
 * gmfnsrsbh   - 购买方税号
 * gmfdz       - 购买方地址
 * gmflxdh     - 购买方电话
 * gmfkhh      - 购买方开户银行
 * gmfyhzh     - 购买方银行账号
 * xsfmc       - 销售方名称（自动填充）
 * xsfnsrsbh   - 销售方税号（自动填充）
 * bz          - 备注
 * skr         - 收款人
 * fhr         - 复核人（注意：API字段名是fhr，但UI上显示为复核人）
 * kpr         - 开票人
 * gmfjbr      - 经办人姓名
 * jbrsfzjhm   - 经办人证件号码
 * jbrsfzjzlDm - 经办人证件类型代码（201=居民身份证）
 * jbrgjDm     - 经办人国籍代码（156=中国）
 * jbrZrrNsrsbh- 经办人自然人纳税人识别号
 * zrrzjlxDm   - 自然人证件类型代码
 * zrrzjhm     - 自然人证件号码
 * zrrgjDm     - 自然人国籍代码
 * fppzDm      - 发票票种代码（01=增值税专用发票）
 * tdyslxDm    - 特定要素类型代码（03=建筑服务）
 * cezslxDm    - 差额征税类型代码（01=全额开票）
 * hjje        - 合计金额
 * hjse        - 合计税额
 * jshj        - 价税合计
 * 
 * jzfwTdys 对象（建筑服务特定要素）：
 *   kdsbz      - 跨地标志（Y=是, N=否）
 *   jzfwfsd    - 建筑服务发生地
 *   xzqhszDm   - 行政区划代码（如 110117=北京市平谷区）
 *   jzxmmc     - 建筑项目名称
 *   kqysssxbgglbm - 跨区域涉税事项报验管理编号
 * 
 * 调用示例：
 * batchSaveDrafts([
 *   { gmfdz: '深圳南山测试1', bz: 'openclaw 的测试', skr: '收款人1', fhr: '复核人1', gmfjbr: '姓名1', jbrsfzjzlDm: '201', jbrsfzjhm: '210102196409297861', zrrzjlxDm: '201', zrrzjhm: '210102196409297861', zrrgjDm: '156', jbrgjDm: '156', jbrZrrNsrsbh: '210102196409297861' },
 *   { gmfdz: '深圳南山测试2', bz: 'openclaw 的测试', skr: '收款人1', fhr: '复核人1', gmfjbr: '姓名1', jbrsfzjzlDm: '201', jbrsfzjhm: '210102196409297861', zrrzjlxDm: '201', zrrzjhm: '210102196409297861', zrrgjDm: '156', jbrgjDm: '156', jbrZrrNsrsbh: '210102196409297861' },
 * ])
 */
