#Requires -Version 5.1
<#
.SYNOPSIS
    Windows 版蓝字发票开票脚本
.DESCRIPTION
    用于在 Windows 系统上执行电子税务局蓝字发票开具
.EXAMPLE
    $env:INVOICE_TYPE = '增值税专用发票'
    $env:BUYER_NAME = '天津智行中天科技有限公司'
    $env:PROJECT_NAME = '*现代服务*推广服务费'
    $env:AMOUNT_VALUE = '5000'
    $env:REMARK_VALUE = '三月推广费'
    .\run-blue-invoice.ps1
#>

[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"

# 获取配置
$Profile = if ($env:BROWSER_PROFILE) { $env:BROWSER_PROFILE } else { "chrome" }
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Template = Join-Path $ScriptDir "blue-invoice-run.template.js"

# 验证必需参数
$requiredVars = @('INVOICE_TYPE', 'BUYER_NAME', 'PROJECT_NAME', 'AMOUNT_VALUE', 'REMARK_VALUE')
foreach ($var in $requiredVars) {
    if (-not (Get-Item Env:$var -ErrorAction SilentlyContinue)) {
        Write-Error "错误: 环境变量 $var 未设置"
        exit 1
    }
}

# 创建临时文件
$FnFile = [System.IO.Path]::GetTempFileName()
$FnFile = $FnFile -replace '\.tmp$', '.js'

try {
    # 读取模板并替换变量
    $TemplateContent = Get-Content -Path $Template -Raw -Encoding UTF8
    
    $replacements = @{
        '__INVOICE_TYPE__' = ($env:INVOICE_TYPE | ConvertTo-Json)
        '__BUYER_NAME__' = ($env:BUYER_NAME | ConvertTo-Json)
        '__PROJECT_NAME__' = ($env:PROJECT_NAME | ConvertTo-Json)
        '__AMOUNT_VALUE__' = ($env:AMOUNT_VALUE | ConvertTo-Json)
        '__REMARK_VALUE__' = ($env:REMARK_VALUE | ConvertTo-Json)
    }
    
    foreach ($key in $replacements.Keys) {
        $TemplateContent = $TemplateContent.Replace($key, $replacements[$key])
    }
    
    # 写入临时文件
    $TemplateContent | Set-Content -Path $FnFile -Encoding UTF8 -NoNewline
    
    Write-Host "正在执行发票开具脚本..." -ForegroundColor Cyan
    
    # 执行浏览器脚本
    $JsContent = Get-Content -Path $FnFile -Raw
    $Result = openclaw browser --browser-profile $Profile evaluate --fn $JsContent
    
    Write-Output $Result
    
    # 检查是否成功并截图
    if ($Result -match '"ok":\s*true' -and $Result -match '"step":\s*"click-preview"') {
        Write-Host "执行成功，正在截图..." -ForegroundColor Green
        Start-Sleep -Seconds 1
        openclaw browser --browser-profile $Profile screenshot
    }
}
finally {
    # 清理临时文件
    if (Test-Path $FnFile) {
        Remove-Item $FnFile -Force -ErrorAction SilentlyContinue
    }
}
