# 登录页 - 技术文档

## 页面信息
- URL: `https://etax.beijing.chinatax.gov.cn:8443/loginb/`
- 标题: 国家税务总局北京市电子税务局

## 登录流程
1. 填写税号（统一社会信用代码）
2. 填写手机号
3. 填写密码
4. 点击"获取验证码"前需完成图形验证码（点选汉字）
5. 用户手动完成图形验证码
6. 点击"获取验证码"发送短信
7. 用户提供短信验证码，AI 填入
8. 点击登录

## 图形验证码
- 类型：点选汉字验证码（如"请依次点击：鼢 鳀 李 雪"）
- AI 无法可靠识别，需用户手动完成
- 点错会刷新验证码

## 登录后跳转
- 登录成功后页面跳转到首页，URL 变化会导致 Browser Relay 断开
- 需要用户重新点击 Relay 扩展图标激活
- 重新 attach 后，优先用 `openclaw browser --browser-profile chrome tabs` 验证，不要只看默认 profile

## Browser Relay / Profile 排障
- 税务局业务页面默认按用户自己的 Chrome + Relay 处理，对应 OpenClaw 的 `chrome` profile
- 若 `openclaw browser status` 显示默认 profile `openclaw` 且 `running: false`，这**不代表**税务页不可控
- 必须补查：
  - `openclaw browser --browser-profile chrome status`
  - `openclaw browser --browser-profile chrome tabs`
- 只有 `chrome` profile 也没有目标 tab，才继续排查 Relay、扩展重连、页面跳转断开等问题

## 表单元素
- 税号输入框
- 手机号输入框
- 密码输入框
- 图形验证码区域
- 短信验证码输入框
- 获取验证码按钮
- 登录按钮
