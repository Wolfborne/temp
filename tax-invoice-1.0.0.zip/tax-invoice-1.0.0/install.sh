#!/bin/bash
# Tax Invoice Skill 安装脚本

set -e

SKILL_NAME="tax-invoice"
INSTALL_DIR="${HOME}/.openclaw/workspace/skills/${SKILL_NAME}"

echo "🦀 安装 Tax Invoice Skill..."

# 检查 OpenClaw 是否安装
if ! command -v openclaw &> /dev/null; then
    echo "❌ 错误：未找到 openclaw 命令，请先安装 OpenClaw"
    exit 1
fi

# 创建目录
mkdir -p "${INSTALL_DIR}"

# 复制文件
echo "📦 复制文件到 ${INSTALL_DIR}..."
cp -r ./* "${INSTALL_DIR}/"

# 设置脚本权限（Linux/Mac 需要，Windows 不需要）
if [[ "$OSTYPE" == "linux-gnu"* ]] || [[ "$OSTYPE" == "darwin"* ]]; then
    chmod +x "${INSTALL_DIR}/scripts/run-blue-invoice.sh"
fi

echo "✅ 安装完成！"
echo ""
echo "下一步："
echo "1. 配置企业信息（可选）："
echo "   cp ${INSTALL_DIR}/config/company.json.example ${INSTALL_DIR}/config/company.json"
echo ""
echo "2. 验证浏览器连接："
echo "   openclaw browser --browser-profile chrome status"
echo ""
echo "3. 开始使用，在 OpenClaw 中输入：帮我开一张发票"
